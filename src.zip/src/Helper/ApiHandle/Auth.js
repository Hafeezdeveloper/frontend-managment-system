// // auth.js
// import Cookies from 'js-cookie';

// export const isAuthenticated = () => {
//   return !!Cookies.get('authToken');
// };

// export const login = (token) => {
//   Cookies.set('authToken', token, { expires: 1 }); // Expires in 1 day
// };

// export const logout = () => {
//   Cookies.remove('authToken');
// };
